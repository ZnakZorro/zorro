const notify = document.querySelector("#notification")
const message = document.querySelector("#message")
const button = document.querySelector("button")
const header = document.querySelector("#header")
const reply = document.querySelector("#reply")
const YamahaIMG = document.querySelector("#YamahaIMG")


//const socket = io("http://localhost:8880")
const socket = io("http://192.168.31.132:8880/");

io.prototype.generateId = function (req) {
    // generate a new custom id here
    return 1
}


const slij=(ten,v)=>{
    document.getElementById("message").value=v;
    document.getElementById("formSend").click(); 
    document.querySelectorAll("#klawisze button").forEach(b=>b.classList.remove("active"));
    document.querySelectorAll("#presets button").forEach(b=>b.classList.remove("active"));
    console.log(ten)
    if (ten) ten.classList.add("active");
}

const slidesVol=(ten)=>{
    let val = ten.value;
    slij(ten,"vol:"+val);
    document.querySelector("#slideval").textContent = val;
}   

const setPowerButton=(d)=>{
    console.log(d,"standby="+(d==="standby")," on="+(d==="on"));
    header.classList=d; 
    let btnon  = document.querySelector("#poweron");
    let btnoff = document.querySelector("#poweroff");
    if (d==="on")      {btnon.classList="disable"; btnoff.classList="blue";}
    if (d==="standby") {btnon.classList="red"; btnoff.classList="disable";}
    if (d==="standby") {    //btnon.classList="red";btnoff.classList="disable"; 
                            //btnon.disabled="false"; btnoff.disabled="true"
                        }
}
socket.on('connect', function() {
    console.log(socket.io.engine.id);     // old ID
    socket.customId = "mee";
    //socket.io.engine.id = 'new ID';
    //console.log(socket.io.engine.id);     // new ID
});

function printMessage(e) {
    console.log("send=",message.value)
    e.preventDefault()
    socket.emit("message", message.value)   // ,{ customId:"000CustomIdHere0000" }
}

socket.on("presets", data => {
    console.log("*******presets=",data)
    let HTML ="";
    data.forEach((d,i)=>{
        const ii=i+1;
        //const ntx = d.tx.replace(/[\])}[{(]/g, '');
        const ntx = d.tx.replace(/\(.*?\)/g, '');
        HTML += `<button onclick='slij(this,"fav:${d.nr}")' class="pres">${ii}. ${ntx}</button>`;
    })
    document.querySelector("#presets").innerHTML = HTML;
});

socket.on("response", data => {
    console.log("response=",data)
    //data = data.replaceAll("  ","<br />")
    let HTML="";
    //console.log(data.volume,data.volume)
    if (data.input) {HTML += ' '+data.input+"; ";}
    if (data.power) {HTML += ' '+data.power+"; ";setPowerButton(data.power);}
    if (data.sleep) {HTML += ' '+data.sleep+"; ";}
    if (data.mute)  {HTML += ' '+data.mute+"; ";}
    HTML += '<br />';    
    if (data.volume) {HTML += 'Vol: '+data.volume+"dB "; document.querySelector("#slideval").textContent=data.volume; document.querySelector("#svolume").value=data.volume;}
    if (data.format) {HTML += ' '+data.format+"/"+data.fs+'; ';}
    HTML += '<br />';
    if (data.artist) {HTML += data.artist+"<br />";}
    if (data.track)  {HTML += data.track+"; ";}
    if (data.album)  {HTML += data.album+"; ";}
    notify.innerHTML = HTML
    if (data.albumart_url) YamahaIMG.src = 'http://'+data.url+data.albumart_url;    else YamahaIMG.src = "gramofon512.jpg";

    header.classList.add("ready");
    //header.style.height = "20vh"
})

button.addEventListener("click", printMessage)

document.addEventListener("DOMContentLoaded",function(){
    slij(null,"list:preset")
});
