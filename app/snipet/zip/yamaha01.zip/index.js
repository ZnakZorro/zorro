const express = require("express")
const app = express()
const http = require("http").Server(app)
const PORT = process.env.PORT || 8880
const path = require("path")
const socketIO = require("socket.io")(http);
    const yamahaURL = "192.168.31.155";
    const YamahaYXC = require("yamaha-yxc-nodejs");
    const yamaha = new YamahaYXC("192.168.31.155");

let gSocket = null;
let GLOB={}

app.use(express.static("public"))

socketIO.on("connection", socket => {
    gSocket = socket;
    console.log(`⚡⚡⚡: ${socket.id} user just connected`)
    socket.on("message", data => {
        let radioIN = "net_radio";
        if (GLOB.input) radioIN = GLOB.input;
        let arr = data.split(":");
        console.log(socket.id,radioIN,"message=",data,"arr=",arr);

        if (arr[0]==="vol"){yamaha.setVolumeTo(arr[1], zone)}
        if (arr[0]==="power"){
            if (arr[1]==="on")  yamaha.powerOn(zone);
            if (arr[1]==="off") yamaha.powerOff(zone);
        }
        if (arr[0]==="fav"){yamaha.recallPreset(arr[1], zone);}
        if (arr[0]==="in"){yamaha.setInput(arr[1], zone);}
        if (arr[0]==="go"){yamaha.setPlayback(radioIN,arr[1]);}
        //yamaha.setPlayback(where, val) //if where is empty the netusb is called, otherwise val must be set to "cd". val is for commands e.g. 'next'
        //Specifies playback statusValues: "play" / "stop" / "pause" / "play_pause" / "previous" / "next" /"fast_reverse_start" / "fast_reverse_end" / "fast_forward_start" /"fast_forward_end"
        //yamaha.setInput(input, zone, mode)
 
        //yamaha.getSettings().then(function(res){console.log("getSettings=",res)})
        //yamaha.getFeatures().then(function(res){console.log("getFeatures=",res)})
        if (arr[0]==="list"){
            if (arr[1]==="preset"){
                yamaha.getPresetInfo().then(function(res){
                    if (res.response_code===0){
                        let list = res.preset_info;
                        //console.log("getPresetInfo List=",list)
                        let presets=[]
                        list.forEach((l,i)=>{
                            let ii=i+1;
                            if (l.text){presets.push({"nr":ii,"tx":l.text});}
                        })
                        console.log(presets)
                        gSocket.emit("presets",presets)
                    }
                })
            }
        }
        sendInfo2Client(socket);
        //socket.emit("response", "emit:: "+data);
        //sends the data to everyone except you.
        //socket.broadcast.emit("response", "bbb="+data);
    })
    socket.on('disconnect', () => {
        console.log(`⚡ ⚡: ${socket.id} user just disconnected`);        
    });
})

/*yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy*/
let zone = "main";


const showOBJstatus=(o,inf="val")=>{
    for (let k in o){
        console.log(inf,k,"\t",o[k])
    }
}

const sendInfo2Client=(socket)=>{
    let zone = "main";
    let OBJ={};
    yamaha.getStatus(zone).then(function(res){
        OBJ.url=yamahaURL;
        if (res.response_code ===0) {
            if (res.volume) OBJ.volume = res.volume;
            if (res.power)  OBJ.power  = res.power;
            if (res.sleep)  OBJ.sleep  = res.sleep;
            if (res.mute)   OBJ.mute   = res.mute;
            if (res.input)  {OBJ.input  = res.input;GLOB.input  = res.input;}
            yamaha.getPlayInfo().then(function(res){
                if (res.response_code ===0) {                    
                    if (res.artist) OBJ.artist = res.artist;
                        if (res.album)  OBJ.album  = res.album;
                        if (res.track)  OBJ.track  = res.track;
                        if (res.albumart_url)  OBJ.albumart_url  = res.albumart_url;
                        
                }
                yamaha.getSignalInfo(zone).then(function(res){ 
                    if (res.response_code ===0) {
                        if (res.audio.format) OBJ.format = res.audio.format;
                        if (res.audio.fs)     OBJ.fs     = res.audio.fs;
                        socket.emit("response", OBJ);
                    }
                }); 

            });
                    
        }        
    });
 
    
}

const isendInfo2Client=()=>{
    if (gSocket) sendInfo2Client(gSocket)
};
/*yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy*/

setInterval(isendInfo2Client,3000)









app.get("/", (req, res)=> {
    res.sendFile(path.join(__dirname, "/index.html"))
})


http.listen(PORT, ()=> {
    console.log(`App listening at ${PORT}`)
} )



/*
getPlayInfo response_code 	 0
getPlayInfo input 	 net_radio
getPlayInfo play_queue_type 	 system
getPlayInfo playback 	 play
getPlayInfo repeat 	 off
getPlayInfo shuffle 	 off
getPlayInfo play_time 	 465
getPlayInfo total_time 	 0
getPlayInfo artist 	 Radio TOK FM (Warsaw/Polish)
getPlayInfo album 	 
getPlayInfo track 	 
getPlayInfo albumart_url 	 /YamahaRemoteControl/AlbumART/AlbumART5716.png
getPlayInfo albumart_id 	 5716
getPlayInfo usb_devicetype 	 msc
getPlayInfo auto_stopped 	 false
getPlayInfo attribute 	 16785411
getPlayInfo repeat_available 	 []
getPlayInfo shuffle_available 	 []
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
getStatus response_code 	 0
getStatus power 	 on
getStatus sleep 	 0
getStatus volume 	 16
getStatus mute 	 false
getStatus max_volume 	 63
getStatus input 	 net_radio
getStatus distribution_enable 	 true
getStatus link_control 	 standard
getStatus link_audio_quality 	 compressed
getStatus disable_flags 	 0
*********************************************************************************
*/